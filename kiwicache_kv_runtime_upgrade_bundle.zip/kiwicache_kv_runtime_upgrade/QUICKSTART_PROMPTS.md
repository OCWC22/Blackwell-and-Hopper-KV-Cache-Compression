# Root Quickstart Prompts

## Route to the right track

```text
Work inside the repo root.
Read README.md, EXECUTIVE_DECISION_MEMO.md, COMPLETE_CONTEXT_AND_CHECKLIST.md, AGENTS.md, CLAUDE.md, Blackwell/README.md, and Hopper/README.md.

Then answer:
1. Should this task live in Blackwell/ or Hopper/?
2. What exact files should be edited first?
3. What is the smallest credible execution plan?

Then make the edits instead of stopping at a recommendation.
```
