# Dual-Track Router

This repo has two tracks.

- `Blackwell/` = hackathon execution lane
- `Hopper/` = longer-horizon research lane

## Routing rule

- If the task is about `B200`, `NVFP4`, weekend validation, `KVTC` tiering, or hackathon deliverables, work in `Blackwell/`.
- If the task is about `H100`, `H200`, packed `FP4`-like storage, direct `FP8` reconstruction, or longer-horizon research, work in `Hopper/`.

Do not mix the two tracks in one edit set.

## Read first

- `README.md`
- `EXECUTIVE_DECISION_MEMO.md`
- `COMPLETE_CONTEXT_AND_CHECKLIST.md`
- track `README.md`
- track `AGENTS.md`
- track context brief

## Hard constraints

- Never claim native `NVFP4` on Hopper.
- Never run GPU jobs on login nodes.
- Prefer official NVIDIA, vLLM, LMCache, and primary-paper sources.
- Optimize for latency plus quality, not compression ratio in isolation.
