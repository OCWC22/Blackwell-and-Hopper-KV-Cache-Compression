# Blackwell KV Runtime

This directory is the hackathon execution lane.

## Thesis

1. keep hot or active KV in native `NVFP4`
2. move stale, reusable, or oversized KV into a `KVTC` warm or cold tier
3. optimize the promotion path from `KVTC` back into `NVFP4`
4. preserve quality while reducing HBM pressure and keeping decode latency low

We are not trying to replace `vLLM` or `LMCache`.

- `vLLM` remains the serving baseline
- `LMCache` remains the storage / lifecycle baseline
- the wedge is the Blackwell-native runtime and policy layer

## Validation ladder

1. `BF16`
2. `FP8`
3. native `NVFP4`
4. optional `LMCache` host-path baseline
5. `NVFP4 + KVTC`
6. promotion-policy ablations

## Quick start

```bash
bash scripts/sync_skills.sh
bash scripts/check_cluster.sh
bash scripts/setup_env.sh
srun --gpus=1 --time=00:10:00 --pty bash
bash scripts/check_gpu.sh
exit
sbatch scripts/baseline_inference.sh
```
