# Quickstart Prompts — Blackwell

## Repo recon

```text
Work inside Blackwell/.
Read README.md, AGENTS.md, CLAUDE.md, QUICKSTART_PROMPTS.md, blackwell_kv_hackathon_context.md, PROMPT_BLACKWELL_NVFP4_KVTC.md, BLACKWELL_24H_PRD.md, B200_SLURM_EVAL_RUNBOOK.md, and scripts/.

Then answer with concrete file edits:
1. What can this repo run today on Blackwell?
2. What is the shortest path to aligned BF16, FP8, and NVFP4 baselines?
3. What is the next missing piece for a credible NVFP4 + KVTC tiering experiment?

Constraints:
- Blackwell first
- native NVFP4 hot KV
- KVTC warm/cold tier
- smallest useful set of edits over a long memo
```
