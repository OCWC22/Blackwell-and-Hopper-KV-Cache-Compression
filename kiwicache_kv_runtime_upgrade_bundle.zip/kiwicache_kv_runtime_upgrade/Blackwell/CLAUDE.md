# Blackwell Claude Guide

## Scope

Use this directory for the hackathon execution lane only.

## Read first

- `README.md`
- `AGENTS.md`
- `blackwell_kv_hackathon_context.md`
- `BLACKWELL_24H_PRD.md`
- `B200_SLURM_EVAL_RUNBOOK.md`

## Success rule

Every change should either improve the benchmark harness, improve result comparability, improve the runbook, or make `NVFP4 + KVTC` policy validation easier.
