# Blackwell 24-Hour PRD

## Objective

Validate a Blackwell-native KV runtime that keeps hot KV in `NVFP4`, uses `KVTC` as a warm or cold tier, and shows a defensible memory-versus-latency-versus-quality tradeoff on `B200` hardware.

## Deliverables

1. aligned `BF16`, `FP8`, and `NVFP4` baseline results
2. first `NVFP4 + KVTC` tiering result
3. one explicit promotion-policy ablation
4. one profile or bottleneck explanation
5. one short decision memo: continue, pivot, or kill

## Workstreams

### 0. Environment and cluster verification
- verify B200 visibility
- capture `nvidia-smi`, driver, CUDA, and Slurm metadata
- record shared-storage and scratch-path assumptions

### 1. Baseline harness hardening
- make `scripts/run_baseline.py` write stable JSON
- make `scripts/baseline_inference.sh` safe on shared Slurm
- add explicit KV mode metadata
- verify repeated runs are comparable

### 2. Single-GPU ladder
- run `BF16`
- run `FP8`
- run `NVFP4`
- compare memory, `p50`, `p95`, throughput, and quality

### 3. First `NVFP4 + KVTC` result
- define the resident hot tier
- define what goes to `KVTC`
- log promotion and protection policy settings
- run one integrated result

### 4. Promotion-policy ablations
- eager vs demand promotion
- recent-window protection on/off
- sink or pivot protection on/off

### 5. Profiling and bottleneck analysis
- capture `nsys` or `ncu`
- identify top bottleneck
- record the top three next optimizations
