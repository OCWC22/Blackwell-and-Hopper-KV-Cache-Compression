# B200 Slurm Eval Runbook

## Rules

- never run GPU workloads on login nodes
- use `srun` for interactive checks only
- use `sbatch` for benchmark jobs
- keep artifacts under `results/` and logs under `logs/`

## First session

```bash
ssh <user>@<login-node>
sinfo
squeue -u $USER
df -h
```

## GPU sanity check

```bash
srun --gpus=1 --time=00:10:00 --pty bash
nvidia-smi
bash scripts/check_gpu.sh
exit
```

## Baseline job

```bash
sbatch scripts/baseline_inference.sh
squeue -u $USER
tail -f logs/kv-baseline-<jobid>.out
```
