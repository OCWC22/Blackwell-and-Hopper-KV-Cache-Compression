from dataclasses import dataclass
from typing import Literal, Optional

PromotionPolicy = Literal["none", "eager", "demand"]
ProtectionPolicy = Literal["none", "recent_window", "sink_tokens", "both"]

@dataclass
class KVRuntimePolicy:
    kv_mode: str
    promotion_policy: PromotionPolicy = "none"
    protection_policy: ProtectionPolicy = "none"
    recent_window_tokens: int = 128
    sink_tokens: int = 4
    notes: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "kv_mode": self.kv_mode,
            "promotion_policy": self.promotion_policy,
            "protection_policy": self.protection_policy,
            "recent_window_tokens": self.recent_window_tokens,
            "sink_tokens": self.sink_tokens,
            "notes": self.notes,
        }
