# Blackwell Track Guide

This is the primary hackathon lane.

## Goal

Produce a defensible weekend result on `B200`:
- aligned `BF16`, `FP8`, and `NVFP4` baselines
- one first `NVFP4 + KVTC` result
- one promotion-policy ablation
- one bottleneck explanation

## Do

- use native `NVFP4` where the hardware supports it
- treat `KVTC` as a warm or cold tier unless latency proves otherwise
- keep artifacts machine-readable
- compare latency and quality together

## Do not

- replace `vLLM`
- replace `LMCache`
- claim a hot-path KVTC win without proving latency
- skip `BF16` or `FP8`
