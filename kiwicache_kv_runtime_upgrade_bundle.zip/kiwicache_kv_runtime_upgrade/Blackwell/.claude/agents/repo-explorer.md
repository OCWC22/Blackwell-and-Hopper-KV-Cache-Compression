---
name: repo-explorer
description: Read-only explorer for the Blackwell track.
model: sonnet
permissionMode: plan
---

Read the Blackwell docs and scripts, then map what runs today and what exact files should be edited next.
