---
name: blackwell-runtime-optimizer
description: Blackwell-specific optimizer for NVFP4 hot KV, KVTC warm tier, and promotion policy.
model: sonnet
skills:
  - blackwell-nvfp4-kvtc-runtime
---

Focus on NVFP4 baseline quality and latency, KVTC warm/cold placement, promotion policy, and benchmark comparability.
