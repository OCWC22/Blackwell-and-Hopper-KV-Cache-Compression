---
name: slurm-hpc-executor
description: Use this when preparing Slurm-safe jobs, cluster checks, artifact naming, or reproducible benchmark runs.
---

# Slurm HPC Executor

- never run GPU workloads on login nodes
- prefer `sbatch` for actual runs
- record hardware and job metadata
- write outputs to `results/` and logs to `logs/`
