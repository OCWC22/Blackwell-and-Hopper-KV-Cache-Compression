---
name: blackwell-nvfp4-kvtc-runtime
description: Use this when working on Blackwell-native KV cache optimization, NVFP4 hot KV, KVTC warm or cold tiering, promotion policy, decode latency, or long-context serving experiments.
---

# Blackwell NVFP4 + KVTC Runtime

## Mission
Build and validate a Blackwell-native KV-cache runtime that:
- keeps active KV in `NVFP4`
- stores stale or reusable KV in `KVTC`
- minimizes promotion latency from `KVTC -> NVFP4`
- preserves accuracy while improving long-context or batch scalability

## Required baselines
- `BF16`
- `FP8`
- native `NVFP4`
- optional `LMCache` host-path baseline
- `NVFP4 + KVTC`

## Deliverable
Return exact file edits, exact run commands, and a benchmark table that includes latency and quality together.
