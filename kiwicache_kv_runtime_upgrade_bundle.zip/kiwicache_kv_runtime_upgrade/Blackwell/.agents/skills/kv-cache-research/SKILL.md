---
name: kv-cache-research
description: Use this when reading or applying NVFP4, KVTC, vLLM KV cache, LMCache, or long-context serving references.
---

# KV Cache Research

Always answer:
- what the source actually claims
- what it does not claim
- how it changes the benchmark ladder
- what concrete edit it implies
