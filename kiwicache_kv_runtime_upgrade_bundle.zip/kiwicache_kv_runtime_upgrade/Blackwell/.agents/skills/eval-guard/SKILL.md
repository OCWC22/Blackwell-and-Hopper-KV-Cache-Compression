---
name: eval-guard
description: Use this when reviewing whether a benchmark claim is honest, comparable, and reproducible.
---

# Eval Guard

A result is not credible unless it includes:
- model
- hardware
- context
- batch size
- kv mode
- p50/p95 latency
- throughput
- memory
- quality or an explicit note that quality was not measured yet
