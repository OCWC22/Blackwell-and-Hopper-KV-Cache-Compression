#!/usr/bin/env bash
#SBATCH --job-name=kv-baseline
#SBATCH --gpus=1
#SBATCH --cpus-per-gpu=16
#SBATCH --mem=128G
#SBATCH --time=01:30:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

set -euo pipefail
mkdir -p logs results

TS=$(date +%Y%m%d_%H%M%S)
MODEL=${MODEL:-meta-llama/Llama-3.1-8B-Instruct}
CONTEXTS=${CONTEXTS:-"8192 32768 65536"}
REPEATS=${REPEATS:-3}

source .venv/bin/activate 2>/dev/null || true

echo "=== Baseline ladder ==="
echo "Start: $(date)"
echo "Node: $(hostname)"
echo "GPU: $(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)"

echo "--- BF16 ---"
python3 scripts/run_baseline.py --model "$MODEL" --context-lengths $CONTEXTS --kv-mode bf16 --engine vllm_python --repeats "$REPEATS" --output "results/${TS}_bf16.json"

echo "--- FP8 ---"
python3 scripts/run_baseline.py --model "$MODEL" --context-lengths $CONTEXTS --kv-mode fp8 --engine vllm_python --repeats "$REPEATS" --output "results/${TS}_fp8.json"

echo "--- NVFP4 external placeholder ---"
python3 scripts/run_external_mode.py --mode nvfp4 --model "$MODEL" --context-length 8192 --batch-size 1 --output "results/${TS}_nvfp4_placeholder.json"

echo "End: $(date)"
