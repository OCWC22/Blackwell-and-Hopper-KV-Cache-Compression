#!/usr/bin/env python3
# Honest placeholder for external NVFP4 / NVFP4+KVTC execution.

import argparse, json, platform, subprocess, time, uuid
from pathlib import Path


def gpu_name():
    try:
        out = subprocess.check_output([
            'nvidia-smi', '--query-gpu=name', '--format=csv,noheader'
        ], text=True).strip().splitlines()
        return out[0] if out else 'unknown'
    except Exception:
        return 'unknown'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--mode', required=True, choices=['nvfp4', 'nvfp4_kvtc'])
    p.add_argument('--model', required=True)
    p.add_argument('--context-length', type=int, required=True)
    p.add_argument('--batch-size', type=int, default=1)
    p.add_argument('--policy', default='none')
    p.add_argument('--output', required=True)
    p.add_argument('--command', default='')
    args = p.parse_args()

    run_id = str(uuid.uuid4())[:8]
    started = time.time()
    status = 'placeholder'
    note = 'External runtime command not provided; fill configs/external_engine_templates.yaml or pass --command.'
    if args.command:
        status = 'command_executed'
        try:
            subprocess.run(args.command, shell=True, check=True)
            note = 'External command executed successfully.'
        except subprocess.CalledProcessError as e:
            status = 'command_failed'
            note = f'External command failed: {e}'

    result = {
        'run_id': run_id,
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started)),
        'model': args.model,
        'hardware': {'hostname': platform.node(), 'gpu': gpu_name()},
        'kv_mode': args.mode,
        'engine': 'external',
        'contexts': [args.context_length],
        'summary': {'status': status, 'batch_size': args.batch_size, 'policy': args.policy, 'elapsed_s': round(time.time() - started, 3)},
        'quality': None,
        'notes': note,
    }
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
