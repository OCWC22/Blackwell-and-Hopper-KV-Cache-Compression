#!/usr/bin/env bash
set -euo pipefail
mkdir -p .claude/skills
for d in .agents/skills/*; do
  name="$(basename "$d")"
  rm -rf ".claude/skills/$name"
  ln -s "../../$d" ".claude/skills/$name"
done
echo 'Mirrored .agents/skills into .claude/skills'
