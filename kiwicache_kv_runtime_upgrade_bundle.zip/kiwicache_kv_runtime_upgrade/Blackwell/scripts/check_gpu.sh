#!/usr/bin/env bash
set -euo pipefail

echo '=== GPU check ==='
date
hostname
nvidia-smi
python3 - <<'PY'
try:
    import torch
    print('torch:', torch.__version__)
    print('cuda available:', torch.cuda.is_available())
    if torch.cuda.is_available():
        print('device:', torch.cuda.get_device_name(0))
        print('capability:', torch.cuda.get_device_capability(0))
except Exception as e:
    print('torch check failed:', e)
PY
