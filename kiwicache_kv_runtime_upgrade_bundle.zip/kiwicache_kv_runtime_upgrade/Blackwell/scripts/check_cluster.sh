#!/usr/bin/env bash
set -euo pipefail

echo '=== Cluster check ==='
date
hostname
whoami

echo '\n--- sinfo ---'
command -v sinfo >/dev/null && sinfo || echo 'sinfo not available'

echo '\n--- squeue ---'
command -v squeue >/dev/null && squeue -u "$USER" || echo 'squeue not available'

echo '\n--- storage ---'
df -h || true

echo '\n--- env ---'
python3 --version || true
nvidia-smi || true
