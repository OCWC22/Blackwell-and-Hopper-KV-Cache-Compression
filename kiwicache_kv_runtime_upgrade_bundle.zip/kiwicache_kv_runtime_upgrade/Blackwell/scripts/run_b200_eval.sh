#!/usr/bin/env bash
set -euo pipefail

MODEL=${1:-meta-llama/Llama-3.1-8B-Instruct}
KV_MODE=${2:-bf16}
OUT=${3:-results/manual_eval_$(date +%Y%m%d_%H%M%S).json}

python3 scripts/run_baseline.py --model "$MODEL" --context-lengths 8192 32768 65536 --kv-mode "$KV_MODE" --engine vllm_python --output "$OUT"
