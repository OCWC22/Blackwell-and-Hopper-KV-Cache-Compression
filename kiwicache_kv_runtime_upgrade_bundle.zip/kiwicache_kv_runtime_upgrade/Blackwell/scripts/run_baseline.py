#!/usr/bin/env python3
# Baseline benchmark harness for Blackwell track.

from __future__ import annotations

import argparse, json, platform, statistics, subprocess, time, uuid
from pathlib import Path
from typing import List


def now_iso() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def gpu_name() -> str:
    try:
        out = subprocess.check_output(['nvidia-smi', '--query-gpu=name', '--format=csv,noheader'], text=True).strip().splitlines()
        return out[0] if out else 'unknown'
    except Exception:
        return 'unknown'


def build_prompt(target_tokens: int) -> str:
    seed = 'KV cache optimization matters because long-context inference is often memory-bound. We are measuring latency, throughput, and memory across precision modes. '
    words = seed.split()
    repeat = max(16, target_tokens // max(1, len(words)))
    return ' '.join(words * repeat)


def percentile(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    if len(values) == 1:
        return values[0]
    ordered = sorted(values)
    k = (len(ordered) - 1) * pct
    f = int(k)
    c = min(f + 1, len(ordered) - 1)
    if f == c:
        return ordered[int(k)]
    return ordered[f] * (c - k) + ordered[c] * (k - f)


def run_vllm(model: str, context_lengths: List[int], kv_mode: str, repeats: int, max_tokens: int):
    try:
        import torch
        from vllm import LLM, SamplingParams
    except Exception as e:
        raise RuntimeError('vLLM path unavailable. Install vllm in a compatible environment or use external mode.') from e

    llm_kwargs = {'model': model, 'trust_remote_code': True, 'gpu_memory_utilization': 0.90, 'max_model_len': max(context_lengths)}
    if kv_mode == 'fp8':
        llm_kwargs['kv_cache_dtype'] = 'fp8'
    elif kv_mode not in {'bf16', 'fp8'}:
        raise RuntimeError(f'kv_mode={kv_mode} is not exposed in this Python harness. Use scripts/run_external_mode.py for NVFP4-capable stacks.')

    llm = LLM(**llm_kwargs)
    sampling = SamplingParams(temperature=0.0, max_tokens=max_tokens)

    experiments = []
    for ctx in context_lengths:
        prompt = build_prompt(ctx)
        latencies = []
        tps_values = []
        peak_memories = []
        output_tokens = None
        for _ in range(repeats):
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            t0 = time.perf_counter()
            outputs = llm.generate([prompt], sampling)
            elapsed = time.perf_counter() - t0
            latencies.append(elapsed)
            generated = len(outputs[0].outputs[0].token_ids)
            output_tokens = generated
            tps_values.append(generated / elapsed if elapsed > 0 else 0.0)
            peak_memories.append(torch.cuda.max_memory_allocated() / 1e6)
        experiments.append({
            'context_length': ctx,
            'repeats': repeats,
            'output_tokens': output_tokens,
            'p50_decode_s': round(percentile(latencies, 0.50), 4),
            'p95_decode_s': round(percentile(latencies, 0.95), 4),
            'avg_tokens_per_second': round(statistics.mean(tps_values), 2),
            'peak_memory_mb_max': round(max(peak_memories), 1),
            'peak_memory_mb_avg': round(statistics.mean(peak_memories), 1),
        })
    return experiments


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', default='meta-llama/Llama-3.1-8B-Instruct')
    p.add_argument('--context-lengths', nargs='+', type=int, default=[8192, 32768, 65536])
    p.add_argument('--kv-mode', choices=['bf16', 'fp8', 'nvfp4', 'nvfp4_kvtc'], default='bf16')
    p.add_argument('--engine', choices=['vllm_python', 'external'], default='vllm_python')
    p.add_argument('--max-tokens', type=int, default=128)
    p.add_argument('--repeats', type=int, default=3)
    p.add_argument('--batch-size', type=int, default=1)
    p.add_argument('--output', default='results/baseline.json')
    args = p.parse_args()

    result = {
        'run_id': str(uuid.uuid4())[:8],
        'timestamp': now_iso(),
        'model': args.model,
        'hardware': {'hostname': platform.node(), 'gpu': gpu_name()},
        'kv_mode': args.kv_mode,
        'engine': args.engine,
        'contexts': args.context_lengths,
        'summary': {'batch_size': args.batch_size, 'repeats': args.repeats, 'max_tokens': args.max_tokens},
        'quality': None,
        'notes': None,
    }

    try:
        if args.engine != 'vllm_python':
            raise RuntimeError('Use scripts/run_external_mode.py for external engine paths.')
        experiments = run_vllm(args.model, args.context_lengths, args.kv_mode, args.repeats, args.max_tokens)
        result['summary']['status'] = 'ok'
        result['summary']['experiments'] = experiments
    except Exception as e:
        result['summary']['status'] = 'error'
        result['notes'] = str(e)

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
