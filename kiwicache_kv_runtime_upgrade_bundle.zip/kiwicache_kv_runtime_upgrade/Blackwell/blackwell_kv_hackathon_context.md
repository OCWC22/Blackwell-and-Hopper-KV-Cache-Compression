# Blackwell KV Runtime Hackathon Context

## Thesis

This is the practical hackathon path:

- keep active or hot KV in native `NVFP4`
- move stale, reusable, or oversized KV into a `KVTC` warm or cold tier
- optimize the promotion path from `KVTC` back into `NVFP4`
- preserve quality while lowering HBM pressure and avoiding decode-latency regressions

Treat `vLLM` as the serving baseline and `LMCache` as the storage / offload baseline.
The wedge is the Blackwell-native KV runtime and policy layer, not a replacement inference engine.

## What we are validating

1. aligned `BF16`, `FP8`, and `NVFP4` baselines on the same model and prompt ladder
2. whether `NVFP4` gives enough memory reduction without unacceptable quality loss
3. whether `KVTC` can act as a warm/cold tier without giving back the win in promotion latency
4. which policy wins first:
   - eager promotion
   - demand fetch
   - protected recent window
   - protected sink/pivot tokens

## Architecture hypothesis

```text
Tier 0: resident active KV in NVFP4
    |
    | decode consumes from here
    v
Tier 1: stale / reusable / oversized KV in KVTC form
    |
    | promotion path reconstructs what is needed
    v
Back into Tier 0 NVFP4 for active decode
```

## Metrics

Every run should record:
- model and revision
- context length
- batch size
- KV mode
- `p50` decode latency
- `p95` decode latency
- tokens/sec
- peak HBM usage
- promotion count or hit rate if applicable
- quality delta relative to the best higher-precision baseline

## Source links

- NVIDIA NVFP4 overview: https://developer.nvidia.com/blog/introducing-nvfp4-for-efficient-and-accurate-low-precision-inference/
- NVIDIA KV cache early reuse / Blackwell blog: https://developer.nvidia.com/blog/5x-faster-time-to-first-token-with-nvidia-tensorrt-llm-kv-cache-early-reuse/
- vLLM quantized KV cache docs: https://docs.vllm.ai/usage/quantization/quantized_kvcache/
- vLLM production stack KV docs: https://docs.vllm.ai/projects/production-stack/en/latest/user_manual/kv_cache/index.html
- LMCache docs: https://docs.lmcache.ai/
- KVTC OpenReview: https://openreview.net/forum?id=tMiBQXQ0Cm
