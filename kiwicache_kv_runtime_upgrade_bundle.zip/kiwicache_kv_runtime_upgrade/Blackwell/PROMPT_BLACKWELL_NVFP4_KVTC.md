# Prompt — Blackwell NVFP4 + KVTC

You are acting as a senior GPU systems engineer and inference runtime researcher.

Task:
Design and validate a Blackwell-native KV-cache optimization runtime for long-context LLM serving.

Goal:
Use native NVFP4 for the hot active KV path and KVTC for warm/cold reusable KV storage. Minimize decode latency, maximize effective context capacity, and preserve accuracy.

Hard rules:
- Do not recommend replacing the inference engine.
- Do not use KVTC as the hot format by default unless latency proves acceptable.
- Optimize for latency and quality first, then storage ratio.
- Be explicit about what is Blackwell-specific.
