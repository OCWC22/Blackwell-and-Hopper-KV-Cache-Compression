# Executive Decision Memo

## The decision

Use Blackwell as the primary hackathon path.

- Hot KV stays in native `NVFP4`.
- Warm or cold KV moves into `KVTC`.
- `vLLM` remains the serving baseline.
- `LMCache` remains the offload / persistence / lifecycle baseline.
- The wedge is the runtime and policy layer: what stays resident, what is compressed, when promotion happens, how quality is preserved, and how decode latency stays low.

Use Hopper as the secondary research lane.

- Treat `FP4` as a storage and transport representation, not a native compute claim.
- Reconstruct directly into `FP8`-oriented compute.
- Add quality protection with recent-window and sink/pivot-token rules.
- Use this to test whether some Blackwell KV economics can be backported to deployed `H100/H200` fleets.

## Why this is the right split

### Hackathon

The Blackwell track is the repo's own execution lane and is explicitly framed around `BF16 -> FP8 -> NVFP4 -> NVFP4 + KVTC` plus promotion-policy ablations.

### Company / YC

The company story is not "another cache." The durable story is:

> We are building a KV-memory runtime layer for long-context inference.
> On Blackwell, we use native NVFP4 for hot KV and KVTC for warm/cold retention.
> On Hopper-class fleets, we emulate some of the same economics with packed FP4-like storage and direct FP8 reconstruction.
> Long-term, that runtime becomes the software wedge for future KiwiCache-style hardware offload.

## What we are proving now

1. We can produce aligned `BF16`, `FP8`, and `NVFP4` baselines on the same model/prompt ladder.
2. `NVFP4` lowers KV memory enough to matter on our target workload without unacceptable quality loss.
3. `KVTC` can serve as a warm/cold tier without destroying tail latency.
4. A runtime policy layer on top of `vLLM` + `LMCache` is a credible wedge.

## What we are not proving now

- a new inference engine
- a replacement for `LMCache`
- a complete hardware offload product
- native NVFP4 on Hopper

## What this validates for KiwiCache

If the Blackwell runtime shows a real memory / latency / quality improvement, it strengthens the long-term KiwiCache thesis: software policy wins today, and hardware acceleration for warm/cold KV tomorrow becomes more plausible.
