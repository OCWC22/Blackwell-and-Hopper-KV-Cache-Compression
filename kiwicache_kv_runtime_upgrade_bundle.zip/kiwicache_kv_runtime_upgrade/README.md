# KiwiCache KV Runtime Upgrade Pack

This pack is a repo-ready upgrade bundle for `OCWC22/Hopper-KV-Cache-Compression`.

It does four things:
1. keeps the repo's real split: `Blackwell/` is the hackathon execution lane and `Hopper/` is the longer-horizon research lane;
2. upgrades the harness so Claude Code and Codex can route, benchmark, and hand off work cleanly;
3. adds a more honest baseline benchmark scaffold for `BF16`, `FP8`, and externally-driven `NVFP4` runs;
4. makes the business logic explicit: software-first KV runtime optimization now, hardware-accelerated KiwiCache / KV offload later.

Open first:
- `EXECUTIVE_DECISION_MEMO.md`
- `COMPLETE_CONTEXT_AND_CHECKLIST.md`
- `AGENTS.md`
- `CLAUDE.md`
- `Blackwell/README.md`
- `Hopper/README.md`
