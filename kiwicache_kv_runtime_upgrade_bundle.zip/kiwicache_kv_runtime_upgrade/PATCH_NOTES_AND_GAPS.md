# Patch Notes And Gaps

## What this pack upgrades

- a clearer root decision memo tied to future KiwiCache hardware
- a more explicit benchmark ladder and artifact contract
- fuller Codex and Claude Code subagent files
- reusable skills for Slurm, research, runtime optimization, and eval review
- a more honest Blackwell baseline harness with `kv_mode`, repeated runs, and JSON schema
- an explicit external runtime hook for `NVFP4` and `NVFP4 + KVTC`
- a cleaner separation between Blackwell execution and Hopper research

## Honest limitations that remain

- the Python `vLLM` path in this pack is enough for `BF16` and often `FP8`, but `NVFP4` still depends on the exact Blackwell-capable runtime stack available in your environment
- the `run_external_mode.py` path is deliberately a schema-preserving wrapper, not a fake one-command guarantee
- `KVTC` integration here is scaffold and policy framing, not a full codec implementation
- quality evaluation still needs the specific benchmark set you want to use
