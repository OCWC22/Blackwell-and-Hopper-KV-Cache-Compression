---
name: slurm-hpc-executor
description: Use this when preparing Slurm-safe jobs, cluster checks, artifact naming, or reproducible benchmark runs.
---

# Slurm HPC Executor

- never run GPU jobs on login nodes
- keep outputs deterministic
- always leave exact run commands
