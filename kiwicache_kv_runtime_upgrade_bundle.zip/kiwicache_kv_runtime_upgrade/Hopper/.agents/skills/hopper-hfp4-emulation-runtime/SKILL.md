---
name: hopper-hfp4-emulation-runtime
description: Use this when researching Hopper-compatible FP4-like KV compression, direct FP8 reconstruction, or quality-preserving packed-KV decode paths.
---

# Hopper HFP4 Emulation Runtime

## Mission
Study whether packed `FP4`-like storage plus direct `FP8` reconstruction can deliver a useful latency-memory-quality tradeoff on `H100/H200`.

## Deliverable
Return exact file edits, exact run commands, and a benchmark table versus `BF16` and `FP8`.
