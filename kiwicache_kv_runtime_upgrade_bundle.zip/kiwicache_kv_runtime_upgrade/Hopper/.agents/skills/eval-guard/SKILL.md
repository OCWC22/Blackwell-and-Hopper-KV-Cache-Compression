---
name: eval-guard
description: Use this when reviewing whether a benchmark claim is honest and comparable.
---

# Eval Guard

Reject claims that do not align model, hardware, KV mode, latency, and quality.
