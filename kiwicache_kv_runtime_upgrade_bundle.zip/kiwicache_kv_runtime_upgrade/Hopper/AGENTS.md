# Hopper Track Guide

This is the research lane.

## Goal

Study whether packed `FP4`-like storage plus direct `FP8` reconstruction can deliver some Blackwell-like KV economics on deployed `H100/H200` fleets.

## Do

- keep compute in `FP8`, `BF16`, or `FP16`
- make grouping and scale placement explicit
- benchmark against `BF16` and `FP8`
- keep quality protection explicit

## Do not

- claim native `NVFP4`
- jump to colder tiers before the hot decode path is understood
- focus only on storage ratio if `p95` latency regresses
