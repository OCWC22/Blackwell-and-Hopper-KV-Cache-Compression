# Quickstart Prompts — Hopper

## Repo recon

```text
Work inside Hopper/.
Read README.md, AGENTS.md, CLAUDE.md, QUICKSTART_PROMPTS.md, hopper_kv_compression_hackathon_context.md, PROMPT_HOPPER_HFP4_RESEARCH.md, HOPPER_RESEARCH_PRD.md, and scripts/.

Then answer with concrete file edits:
1. What can this repo run today on H100/H200?
2. What is the shortest path to aligned BF16 and FP8 baselines?
3. What is the next missing piece for a credible packed FP4-like path with direct FP8 reconstruction?

Constraints:
- Hopper only
- no native NVFP4 claims
- focus on the active decode path first
```
