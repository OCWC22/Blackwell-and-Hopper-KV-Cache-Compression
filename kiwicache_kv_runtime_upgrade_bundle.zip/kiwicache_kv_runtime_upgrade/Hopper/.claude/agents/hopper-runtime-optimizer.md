---
name: hopper-runtime-optimizer
description: Hopper-specific optimizer for packed FP4-like storage and direct FP8 reconstruction.
model: sonnet
skills:
  - hopper-hfp4-emulation-runtime
---
