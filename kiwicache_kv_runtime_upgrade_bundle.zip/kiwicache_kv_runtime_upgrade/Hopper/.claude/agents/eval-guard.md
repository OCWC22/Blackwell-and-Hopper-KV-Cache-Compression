---
name: eval-guard
description: Benchmark integrity reviewer for the Hopper track.
model: sonnet
permissionMode: plan
skills:
  - eval-guard
---
