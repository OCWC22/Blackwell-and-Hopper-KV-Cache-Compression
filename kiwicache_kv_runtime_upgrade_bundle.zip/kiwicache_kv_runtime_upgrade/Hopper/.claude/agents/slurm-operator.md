---
name: slurm-operator
description: Slurm and cluster operator for Hopper experiments.
model: sonnet
tools: Bash
skills:
  - slurm-hpc-executor
---
