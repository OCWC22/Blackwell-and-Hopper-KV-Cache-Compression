---
name: repo-explorer
description: Read-only explorer for the Hopper track.
model: sonnet
permissionMode: plan
---

Read the Hopper docs and scripts, then map what runs today and what is still scaffold-only.
