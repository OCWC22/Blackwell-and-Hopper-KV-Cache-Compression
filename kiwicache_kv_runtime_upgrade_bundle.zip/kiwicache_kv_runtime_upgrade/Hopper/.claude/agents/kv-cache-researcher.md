---
name: kv-cache-researcher
description: Research agent for Hopper packed-KV papers and baseline behavior.
model: sonnet
skills:
  - kv-cache-research
---
