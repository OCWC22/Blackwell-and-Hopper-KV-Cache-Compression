#!/usr/bin/env bash
#SBATCH --job-name=hopper-baseline
#SBATCH --gpus=1
#SBATCH --cpus-per-gpu=16
#SBATCH --mem=128G
#SBATCH --time=01:00:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

set -euo pipefail
mkdir -p logs results
source .venv/bin/activate 2>/dev/null || true
python3 scripts/run_baseline.py --kv-mode bf16 --output "results/hopper_bf16_$(date +%Y%m%d_%H%M%S).json"
python3 scripts/run_baseline.py --kv-mode fp8 --output "results/hopper_fp8_$(date +%Y%m%d_%H%M%S).json"
