#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install torch transformers pyyaml
pip install vllm || true
echo 'Environment prepared.'
