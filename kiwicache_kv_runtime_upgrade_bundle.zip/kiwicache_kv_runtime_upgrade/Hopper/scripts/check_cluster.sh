#!/usr/bin/env bash
set -euo pipefail

echo '=== Cluster check ==='
date
hostname
whoami
command -v sinfo >/dev/null && sinfo || true
command -v squeue >/dev/null && squeue -u "$USER" || true
df -h || true
nvidia-smi || true
