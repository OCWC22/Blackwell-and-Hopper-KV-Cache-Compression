# Hopper Research PRD

## Objective

Validate whether packed `FP4`-like KV storage plus direct `FP8` reconstruction can be a credible Hopper wedge.

## Deliverables

1. aligned `BF16` and `FP8` baselines
2. one first packed `FP4`-like storage result
3. one direct `FP8` reconstruction result
4. one quality-protection ablation
5. one decision memo: continue, pivot, or kill

## Kill criteria

- packed representation loses clearly on `p95` decode latency
- quality degrades materially versus `FP8`
- dequant overhead dominates the memory win
