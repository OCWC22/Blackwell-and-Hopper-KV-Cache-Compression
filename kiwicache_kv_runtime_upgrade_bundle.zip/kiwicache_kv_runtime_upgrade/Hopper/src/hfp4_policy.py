from dataclasses import dataclass

@dataclass
class HFP4Policy:
    grouping: str = 'inner_dimension'
    recent_window_tokens: int = 128
    sink_tokens: int = 4
    notes: str | None = None
