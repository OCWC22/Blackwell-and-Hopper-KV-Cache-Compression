# Prompt — Hopper HFP4 Research

You are acting as a senior GPU systems engineer and low-precision runtime researcher.

Task:
Design and validate a Hopper-compatible FP4-like KV-cache runtime that attempts to achieve Blackwell-like quality behavior without native NVFP4 hardware.

Goal:
Store KV in a packed FP4-like format, reconstruct directly into FP8 compute, reduce KV memory and bandwidth, and preserve accuracy with low enough decode overhead to be practical.

Hard rules:
- Do not claim native NVFP4 on Hopper.
- Keep compute FP8-oriented.
- Avoid unnecessary BF16 round-trips.
- Treat dequantization overhead as the main systems risk.
- Optimize for latency-quality tradeoff, not just compression ratio.
