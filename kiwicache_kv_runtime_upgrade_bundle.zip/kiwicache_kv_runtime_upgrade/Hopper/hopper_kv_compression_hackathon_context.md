# Hopper KV Compression Research Context

## Thesis

This is the longer-horizon wedge:

- packed `FP4`-like KV storage on Hopper
- direct reconstruction into `FP8`
- quality protection with recent-window and sink/pivot-token policies
- colder tiers only after the active decode path is credible

## Research question

Can Hopper achieve something close to Blackwell-like 4-bit KV quality and memory savings by using:
- packed `FP4`-like storage
- direct `FP8` reconstruction
- hardware-aware grouping
- protected token windows
- profiling-driven decode-path optimization

## Research ladder

1. `BF16`
2. `FP8`
3. packed `FP4`-like storage
4. direct `FP8` reconstruction
5. recent-window protection
6. sink / pivot-token protection
7. grouping ablations
8. optional colder-tier integration

## Source links

- NVIDIA H100: https://www.nvidia.com/en-us/data-center/h100/
- NVIDIA H200: https://www.nvidia.com/en-us/data-center/h200/
- NVIDIA Hopper architecture: https://developer.nvidia.com/blog/nvidia-hopper-architecture-in-depth/
- vLLM quantized KV cache docs: https://docs.vllm.ai/usage/quantization/quantized_kvcache/
- LMCache docs: https://docs.lmcache.ai/
- PCIe bandwidth reference: https://pcisig.com/sites/default/files/files/PCIe%206.0%20Webinar_Final_.pdf
- Practical FP4 Training for Large-Scale MoE Models on Hopper GPUs: https://arxiv.org/abs/2603.02731
- InnerQ: https://arxiv.org/abs/2602.23200
- KIVI: https://arxiv.org/abs/2402.02750
- IntactKV: https://arxiv.org/abs/2403.01241
- QServe: https://arxiv.org/abs/2405.04532
