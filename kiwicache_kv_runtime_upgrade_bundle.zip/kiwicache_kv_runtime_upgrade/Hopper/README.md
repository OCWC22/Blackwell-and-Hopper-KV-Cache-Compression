# Hopper KV Runtime Research

This directory is the longer-horizon research lane.

## Thesis

1. target deployed `H100` and `H200` fleets, not hypothetical hardware
2. emulate some of the Blackwell KV economics with packed FP4-like storage
3. reconstruct directly into `FP8`-oriented compute on Hopper
4. protect quality with recent-window and sink/pivot-token policies
5. integrate cold-tier storage only after the active decode path is credible

We are not trying to claim native `NVFP4` on Hopper.

## Research ladder

1. `BF16`
2. `FP8`
3. packed `FP4`-like storage
4. direct `FP8` reconstruction
5. quality protection ablations
6. optional `LMCache` cold-tier integration
