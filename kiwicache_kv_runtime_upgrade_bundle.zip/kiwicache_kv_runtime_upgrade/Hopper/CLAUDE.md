# Hopper Claude Guide

## Scope

Use this directory for Hopper research only.

## Read first

- `README.md`
- `AGENTS.md`
- `hopper_kv_compression_hackathon_context.md`
- `HOPPER_RESEARCH_PRD.md`

## Success rule

Every change should either make the packed-KV research path clearer, more measurable, or easier to kill honestly.
