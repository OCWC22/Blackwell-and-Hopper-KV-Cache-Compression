# Claude Code Router

This repo contains two separate but related KV-runtime tracks.

## Routing

- Use `Blackwell/` for the hackathon execution lane.
- Use `Hopper/` for the longer-horizon R&D lane.

Do not blur Blackwell-native behavior with Hopper emulation.

## Workflow

1. Read the root docs.
2. Route into one track.
3. Read the track README, AGENTS, CLAUDE, PRD, and context brief.
4. Make concrete file edits.
5. Leave exact run commands and artifact paths.

## Non-goals

- not a new inference engine
- not a full LMCache replacement
- not fake NVFP4 claims on Hopper
