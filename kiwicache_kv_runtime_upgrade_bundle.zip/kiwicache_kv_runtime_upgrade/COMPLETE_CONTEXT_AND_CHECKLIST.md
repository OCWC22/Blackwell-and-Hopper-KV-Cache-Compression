# Complete Context And Checklist

## What we are doing

### Track A — Blackwell (primary)

- keep active KV in native `NVFP4`
- move stale / reusable / oversized KV into `KVTC`
- optimize promotion from `KVTC` back into `NVFP4`
- benchmark against `BF16`, `FP8`, and optional `LMCache` host-path baselines

### Track B — Hopper (secondary)

- store KV in a packed `FP4`-like representation
- reconstruct directly into `FP8`
- protect quality with recent-window and sink/pivot-token rules
- only add colder tiers after the active decode path is credible

## What we already have

- a repo already split into `Blackwell/` and `Hopper/`
- root router docs telling agents not to mix the tracks
- a Blackwell README and PRD that already define the weekend ladder
- a Hopper README that already defines the long-horizon research ladder
- a simple baseline harness in `Blackwell/scripts/run_baseline.py` and `baseline_inference.sh`

## Current limitations in the repo

- the current Python baseline is useful, but it does not yet provide a full aligned benchmark ladder across `BF16`, `FP8`, and `NVFP4`
- the current baseline uses approximate prompt sizing and records one total timing per context, but not a robust repeated-run percentile table
- the current Slurm baseline runs a single simple path; it does not yet stamp enough KV-mode metadata for a full hackathon table
- the docs are ahead of the benchmark harness

## What we need to add

### Root
- short routing `AGENTS.md`
- short routing `CLAUDE.md`
- root quickstart prompts
- one decision memo tying software optimization to future KiwiCache hardware

### Blackwell
- benchmark harness that can truthfully distinguish `BF16`, `FP8`, `NVFP4`, and `NVFP4 + KVTC`
- result schema with model / revision / hardware / context / batch / KV mode / p50 / p95 / throughput / HBM / quality
- Slurm runbook for `B200`
- explicit prompt files and subagents for Blackwell-only work
- a clear hook for external `NVFP4` execution when Python `vLLM` alone is insufficient

### Hopper
- a clean research harness for `BF16`, `FP8`, and packed `FP4`-like experiments
- explicit kill criteria
- paper-driven quality protection rules

## Hackathon benchmark ladder

### Blackwell ladder
1. `BF16`
2. `FP8`
3. `NVFP4`
4. optional `LMCache` / raw host-path offload
5. `NVFP4 + KVTC`
6. `NVFP4 + KVTC + protected recent window`
7. `NVFP4 + KVTC + protected sink/pivot tokens`

### Hopper ladder
1. `BF16`
2. `FP8`
3. packed `FP4`-like storage
4. direct `FP8` reconstruction
5. quality-protection ablations
6. optional `LMCache` cold-tier follow-up

## Immediate execution order

1. run cluster verification
2. run `BF16` and `FP8` baselines with stable JSON output
3. wire in external `NVFP4` execution path and capture its results in the same schema
4. add `KVTC` warm-tier scaffold and promotion-policy logging
5. only then profile
